﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[10, 2];
            string aux;
            double media1 = 0, media2 = 0;

            lbxOpiniao.Items.Clear();

            for (var i = 0; i < 10; i++)
            {
                for (var j = 0; j < 2; j++)
                {
                    aux = Interaction.InputBox("Digite a Nota do Filme " + (j + 1), "Entrada de Dados");

                    if (!double.TryParse(aux, out notas[i, j]))
                    {
                        MessageBox.Show("Nota Inválida!");
                        j--;
                    }
                    else
                    {
                        if (notas[i, j] < 0 || notas[i, j] > 10)
                        {
                            MessageBox.Show("Nota Inválida!");
                            j--;
                        }
                        else
                        {
                            if (j == 0)
                            {
                                media1 += notas[i, j];
                            }
                            else
                            {
                                media2 += notas[i, j];
                            }
                        }
                    }
                }

               
            }

            for (var i = 0; i < 10; i++)
            {
                lbxOpiniao.Items.Add("Pessoa " + (i + 1) + ": Nota Filme 1: " + notas[i, 0].ToString("N2") + "  Nota Filme 2: " + notas[i, 1].ToString("N2"));
            }

            lbxOpiniao.Items.Add("---------------------------------");

            lbxOpiniao.Items.Add("Média Filme 1 : " + (media1 /= 10).ToString("N2"));
            lbxOpiniao.Items.Add("Média Filme 2 : " + (media2 /= 10).ToString("N2"));
        }
    }
}
